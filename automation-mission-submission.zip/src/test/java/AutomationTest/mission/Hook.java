package AutomationTest.mission;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Hook {
    @Before
    public void before() { BrowserSetup.getDriver(); }

    @After
    public void after(Scenario scenario) {
        WebDriver d = BrowserSetup.getDriver();
        boolean snap = Boolean.parseBoolean(BrowserSetup.prop("ScreenshotOnFail", "true"));
        if (scenario.isFailed() && snap) {
            byte[] shot = ((TakesScreenshot) d).getScreenshotAs(OutputType.BYTES);
            scenario.attach(shot, "image/png", "failed-step");
        }
        BrowserSetup.quitDriver();
    }
}
