Run: mvn clean test (or -Dcucumber.filter.tags=@api / @ui). Reports: test-output/index.html, target/cucumber.html
